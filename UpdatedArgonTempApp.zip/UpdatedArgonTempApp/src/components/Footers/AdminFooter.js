/*!

=========================================================
* Argon Dashboard React - v1.2.2
=========================================================

* Product Page: https://www.creative-tim.com/product/argon-dashboard-react
* Copyright 2022 Creative Tim (https://www.creative-tim.com)
* Licensed under MIT (https://github.com/creativetimofficial/argon-dashboard-react/blob/master/LICENSE.md)

* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

*/
/*eslint-disable*/

// reactstrap components
import { Container, Row, Col, Nav, NavItem, NavLink } from "reactstrap";

const Footer = () => {
  return (
    <footer className="pt-4 pb-2">
    <Container>
      <Row className="align-items-center justify-content-xl-between">
        <Col xl="6">
          <div className="copyright text-center text-xl-left text-muted">
            ©{"  "}
            <img
              style={{ width: "4em" }}
              src={require("../../assets/img/brand/argon-react.png")}
            />
          </div>
        </Col>
        <Col xl="6">
          <Nav
            className="nav-footer justify-content-center justify-content-xl-end"
            style={{ 'cursor': "pointer" }}
          >
            <NavItem>
              <NavLink>About Us</NavLink>
            </NavItem>
            <NavItem>
              <NavLink>Blog</NavLink>
            </NavItem>
            <NavItem>
              <NavLink>MIT License</NavLink>
            </NavItem>
            <NavItem>
              <NavLink>{new Date().getFullYear()}</NavLink>
            </NavItem>
          </Nav>
        </Col>
      </Row>
    </Container>
  </footer>
  );
};

export default Footer;

/*!

=========================================================
* Argon Dashboard React - v1.2.2
=========================================================

* Product Page: https://www.creative-tim.com/product/argon-dashboard-react
* Copyright 2022 Creative Tim (https://www.creative-tim.com)
* Licensed under MIT (https://github.com/creativetimofficial/argon-dashboard-react/blob/master/LICENSE.md)

* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

*/
// reactstrap components
import {
  Card,
  CardHeader,
  Media,
  Table,
  Container,
  Row,
} from "reactstrap";
// core components
import Header from "components/Headers/Header.js";
import { useState } from "react";
const Tables = () => {
  const UserList = [
    {
      id: 0,
      name: "Seth MacFarlane",
      age: 49,
      gender: "Male",
      payed: true,
    },
    {
      id: 1,
      name: "Emma Watson",
      age: 23,
      gender: "Female",
      payed: true,
    },
    {
      id: 2,
      name: "Harry Styles",
      age: 25,
      gender: "Male",
      payed: true,
    },
    {
      id: 3,
      name: "Megan Fox",
      age: 27,
      gender: "Female",
      payed: true,
    },
    {
      id: 4,
      name: "Chris Evans",
      age: 29,
      gender: "Male",
      payed: true,
    },
    {
      id: 5,
      name: "Scarlett Johansson",
      age: 31,
      gender: "Female",
      payed: false,
    },
    {
      id: 6,
      name: "Robert Downey Jr.",
      age: 33,
      gender: "Male",
      payed: false,
    },
    {
      id: 7,
      name: "Margot Robbie",
      age: 35,
      gender: "Female",
      payed: false,
    },
    {
      id: 8,
      name: "Ryan Reynolds",
      age: 37,
      gender: "Male",
      payed: false,
    },
    {
      id: 9,
      name: "Gal Gadot",
      age: 39,
      gender: "Female",
      payed: false,
    },
    {
      id: 10,
      name: "Leonardo DiCaprio",
      age: 41,
      gender: "Male",
      payed: true,
    },
    {
      id: 11,
      name: "Jennifer Lawrence",
      age: 43,
      gender: "Female",
      payed: true,
    },
    {
      id: 12,
      name: "Dwayne Johnson",
      age: 45,
      gender: "Male",
      payed: true,
    },
    {
      id: 13,
      name: "Sofia Vergara",
      age: 47,
      gender: "Female",
      payed: true,
    },
    {
      id: 14,
      name: "Brad Pitt",
      age: 49,
      gender: "Male",
      payed: true,
    },
    {
      id: 15,
      name: "Angelina Jolie",
      age: 51,
      gender: "Female",
      payed: false,
    },
    {
      id: 16,
      name: "Will Smith",
      age: 53,
      gender: "Male",
      payed: false,
    },
    {
      id: 17,
      name: "Cameron Diaz",
      age: 55,
      gender: "Female",
      payed: false,
    },
    {
      id: 18,
      name: "Tom Cruise",
      age: 57,
      gender: "Male",
      payed: false,
    },
    {
      id: 19,
      name: "Sandra Bullock",
      age: 59,
      gender: "Female",
      payed: false,
    },
  ];
  const [currentPage, setCurrentPage] = useState(1);
  const [entriesperPage] = useState(5);
  const indexofLastEntry = currentPage * entriesperPage;
  const indexofFirstEntry = indexofLastEntry - entriesperPage;
  const neededEntries = UserList.slice(indexofFirstEntry, indexofLastEntry);
  const pageNumbers = [];
  for (let i = 1; i <= Math.ceil(UserList.length / entriesperPage); i++) {
    pageNumbers.push(i);
  }
  const paginate = (pageNum) => setCurrentPage(pageNum);
  return (
    <>
      <Header />
      {/* Page content */}
      <Container fluid>
        {/* Table */}
        <Row>
          <div className="col">
            <Card className="shadow">
              <CardHeader className="border-0">
                <h3 className="mb-0 text-center">Users</h3>
              </CardHeader>
              <Table className="align-items-center table-flush" responsive>
                <thead className="thead-light">
                  <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Age</th>
                    <th scope="col">Gender</th>
                    <th scope="col">Payed</th>
                  </tr>
                </thead>
                <tbody>
                  {neededEntries.map((user, index) => (
                    <tr key={index}>
                      <th scope="row">
                        <Media className="align-items-center">
                          <a
                            className="avatar rounded-circle mr-3"
                            href="#pablo"
                            onClick={(e) => e.preventDefault()}
                          >
                            <img
                              alt="..."
                              src={require("../../assets/mynew/icons8-user-24.png")}
                            />
                          </a>
                          <span className="mb-0 text-sm">{user.name}</span>
                        </Media>
                      </th>
                      <td>{user.age}</td>
                      <td>{user.gender}</td>
                      <td>{user.payed ? "YES" : "NO"}</td>
                    </tr>
                  ))}
                </tbody>
              </Table>
              <nav>
                <ul className="pagination justify-content-center">

                  {pageNumbers.map((number) => (
                    <li
                      key={number}
                      className={`page-item mt-1 ${
                        currentPage === number ? "active" : ""
                      }`}
                      style={{"cursor":"pointer"}}>
                      <button onClick={() => paginate(number)} className="page-link" >
                        {number}
                      </button>
                    </li>
                  ))}

                </ul>
              </nav>
            </Card>
          </div>
        </Row>
      </Container>
    </>
  );
};

export default Tables;

import React from 'react'
import ForgetPw from 'views/examples/ForgetPw'

const DummyCom = () => {
  return (
    <div>
        DummyCom
        <ForgetPw />
    </div>
  )
}

export default DummyCom
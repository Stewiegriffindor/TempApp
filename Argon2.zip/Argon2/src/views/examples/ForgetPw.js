import { useState } from "react";
import { Link} from "react-router-dom";
import {
  Col,
  Card,
  CardBody,
  Form,
  FormGroup,
  InputGroup,
  InputGroupAddon,
  InputGroupText,
  Input,
  Button,
} from "reactstrap";

const ForgetPw = () => {
  const [userName, setUserName] = useState("");
  const [display, setDisplay] = useState(false);
  // const history = useHistory();
  const handleLogin = () => {
    setDisplay(true);
  };
  const handleButtonDisable = () => {
    return (userName.length===0)
  }

  return (
    <>
      <Col lg="5" md="7">
        <Card className="bg-secondary shadow border-0">
          <h4 className="text-center mt-4 text-blue">
            Recover Your Password
          </h4>
          <CardBody className="px-lg-5 py-lg-5">
            <div className="text-center text-muted mb-4">
              <small>Enter your E-mail to continue</small>
            </div>
            <Form role="form">
              <FormGroup className="mb-3">
                <InputGroup className="input-group-alternative">
                  <InputGroupAddon addonType="prepend">
                    <InputGroupText>
                      <i className="ni ni-email-83" />
                    </InputGroupText>
                  </InputGroupAddon>
                  <Input
                    placeholder="Email"
                    // type="email"
                    // autoComplete="new-email"
                    value={userName}
                    onChange={(e) => {setUserName(e.target.value)}}
                    onKeyDown={(e)=>{
                      if(e.key==='Enter'){
                        e.preventDefault()
                        if(userName.length!==0){
                          handleLogin()
                        }
                      }
                    }}
                  />
                </InputGroup>
              </FormGroup>
              <div className="text-center">
                <Button
                  className="my-4"
                  color="primary"
                  type="button"
                  disabled={handleButtonDisable()}
                  onClick={() => handleLogin()}

                >
                  Continue
                </Button>
                {display && (
                  <div>
                    <h5 className="mb-3">
                      Follow the instructions provided in the E-mail We've just
                      sent you to recover your password
                    </h5>
                    <Link to='/auth/login'>Back to Login Page</Link>
                  </div>
                )}
              </div>
            </Form>
          </CardBody>
        </Card>
      </Col>
    </>
  );
};

export default ForgetPw;

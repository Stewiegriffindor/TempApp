import React from 'react'

const Policies = () => {
  return (
    <div>
              <div
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <img
            src={require("../../assets/img/brand/argon-react.png")}
            alt=""
            style={{ maxWidth: "100px", margin: "10px" }}
          />
          <h1 className="mt-1">Privacy Policy</h1>
        </div>
      <p className='text-center' >This privacy policy applies to the use of the Argon website.</p>
      <h2 className='ml-5'>Information we collect</h2>
      <p className='ml-6' >We collect information about you when you use our website, including:</p>
      <ul className='ml-7'>
        <li>Your name and contact information</li>
        <li>Information about the products you purchase</li>
        <li>Your browsing activity on our website</li>
      </ul>
      <h2 className='ml-5'>How we use your information</h2>
      <p className='ml-6'>We use your information to:</p>
      <ul className='ml-7'>
        <li>Process your orders</li>
        <li>Improve our website and products</li>
        <li>Communicate with you about our products and promotions</li>
      </ul>
      <h2 className='ml-5'>Sharing your information</h2>
      <p className='ml-6'>We may share your information with:</p>
      <ul className='ml-7'>
        <li>Third-party service providers who help us operate our website and process orders</li>
        <li>Law enforcement agencies if required by law</li>
      </ul>
      <h2 className='ml-5'>Security</h2>
      <p className='ml-6'>We take the security of your information seriously and use industry-standard measures to protect it.</p>
      <h2 className='ml-5'>Changes to this policy</h2>
      <p className='ml-6' >We may update this policy from time to time. If we make significant changes, we will notify you.</p>
    </div>
  )
}

export default Policies
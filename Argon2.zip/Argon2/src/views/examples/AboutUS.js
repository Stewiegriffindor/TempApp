import React from "react";

const AboutUS = () => {
  return (
    <div>
      <div>
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <img
            src={require("../../assets/img/brand/argon-react.png")}
            alt=""
            style={{ maxWidth: "100px", margin: "10px" }}
          />
          <h1 className="mt-1">About</h1>
        </div>

        <p className="ml-2" style={{'fontSize':"1em"}}>
          Argon is a leading provider of environmentally friendly technologies
          for businesses and individuals. We specialize in developing and
          distributing innovative solutions that help reduce waste, conserve
          energy, and protect the planet.
        </p>
        <p className="ml-2" style={{'fontSize':"1em"}}>
          Our mission is to create a sustainable future for all by promoting the
          use of green technologies that benefit the environment and improve
          quality of life.
        </p>
        <h2 className="ml-5">Our History</h2>
        <p className="ml-6" style={{'fontSize':"1em"}}>
          Argon was founded in 2010 by a group of passionate environmentalists
          who recognized the need for more sustainable solutions in the
          marketplace. Since then, we have grown into a thriving company with a
          wide range of products and services.
        </p>
        <h2 className="ml-5 ">Our Products</h2>
        <p className="ml-6" style={{'fontSize':"1em"}}>
          We offer a variety of products designed to meet the needs of
          businesses and individuals who are committed to reducing their
          environmental impact. Our products include:
        </p>
        <ul className="ml-6">
          <li>Solar panels</li>
          <li>LED lighting</li>
          <li>Energy-efficient appliances</li>
          <li>Recycling systems</li>
          <li>Water conservation products</li>
        </ul>
        <h2 className="ml-5 ">Our Team</h2>
        <p className="ml-6" style={{'fontSize':"1em"}}>
          Our team is made up of dedicated professionals with a wide range of
          expertise in green technologies. We are committed to providing our
          customers with the highest level of service and support.
        </p>
        <h2 className="ml-5 ">Contact Us</h2>
        <div
          style={{
            display: "flex",

            flexDirection: "column",
          }}
        >
          <p className="ml-6" style={{'fontSize':"1em"}}>
            Do you have any questions or want to learn more about our products
            and services? Contact us today:
          </p>
          <p
            style={{
              fontWeight: "bold",
              lineHeight:'0',
              'fontSize':"1em"
            }}
          >
            <a
              className="ml-6"
              href="tel:555-555-5555"
              style={{ color: "#007bff", textDecoration: "none" }}
            >
              Tel : 555-555-5555
            </a>{" "}
            | E-mail : info@argon.com
          </p>
          <p className="ml-6">
            We're available Monday through Friday, from 9am to 5pm Eastern
            Standard Time.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AboutUS;

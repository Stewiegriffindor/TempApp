import React, { useState } from "react";
import {
  Container,
  Form,
  FormGroup,
  Label,
  Input,
  Button,
  Card,
  CardBody,
  Modal,
  ModalFooter,
  ModalBody,
  ModalHeader
} from "reactstrap";
import AdminFooter from '../../components/Footers/AdminFooter'


const ContactUs = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [message, setMessage] = useState("");
  const [modalOpen, setModalOpen] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setModalOpen(true)
    setName("");
    setEmail("");
    setPhone("");
    setMessage("");
  };

  return (
    <div>
      <Container>
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <img
            src={require("../../assets/img/brand/argon-react.png")}
            alt=""
            style={{ maxWidth: "100px", margin: "10px" }}
          />
          <h1 className="text-center">Contact Us</h1>
        </div>
        {/* <div className="position-fixed d-none d-md-block" style={{ top: '50px', right: '20px', zIndex: '1000' }}> */}
        <Card
          className="text-center mt-3 mx-auto"
          style={{
            maxWidth: "300px",
            position: "relative",
            borderColor: "skyblue",
          }}
        >
          <CardBody>
            <h3>We love to hear from you!</h3>

            <p className="mb-2">Call us on Our hotline</p>
            <p className="font-weight-bold text-blue">555-555-555</p>
          </CardBody>
        </Card>
        {/* </div> */}

        <div className="mt-4 text-center text-muted">
          <p>Or Enter your details and an Agent will be with you shortly.</p>
        </div>
        <Form onSubmit={handleSubmit}>
          <FormGroup>
            <Label for="name">Name:</Label>
            <Input
              type="text"
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              style={{ width: "40em" }}
              required
            />
          </FormGroup>
          <FormGroup>
            <Label for="email">Email:</Label>
            <Input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              style={{ width: "40em" }}
              required
            />
          </FormGroup>
          <FormGroup>
            <Label for="phone">Phone Number:</Label>
            <Input
              type="tel"
              id="phone"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              style={{ width: "40em" }}
              required
            />
          </FormGroup>
          <FormGroup>
            <Label for="message">Message:</Label>
            <Input
              type="textarea"
              id="message"
              rows={3}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              required
            />
          </FormGroup>
          <Button
            color="primary"
            className="btn-block mt-3 mb-4"
            style={{ width: "7em" }}
          >
            Submit
          </Button>
        </Form>
      </Container>
      <Modal isOpen={modalOpen} toggle={() => setModalOpen(false)} style={{"maxWidth":"26em",}} >
        <ModalHeader toggle={() => setModalOpen(false)}>Thank you</ModalHeader>
        <ModalBody>
          Your message has been sent. We will get back to you as soon as
          possible.
        </ModalBody>
        <ModalFooter className="d-flex justify-content-center">
          <Button color="primary" onClick={() => setModalOpen(false)}>
            Close
          </Button>
        </ModalFooter>
      </Modal>
      <AdminFooter />
    </div>
  );
};

export default ContactUs;

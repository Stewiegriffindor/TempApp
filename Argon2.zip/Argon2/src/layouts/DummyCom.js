import React from "react";
import routes from "routes";
import { Container, Row, Col } from "reactstrap";
import { useLocation, Route, Switch, Redirect } from "react-router-dom";

const DummyCom = () => {
  const getRoutes = (routes) => {
    return routes.map((prop, key) => {
      if (prop.layout === "/dummy") {
        return (
          <Route
            path={prop.layout + prop.path}
            component={prop.component}
            key={key}
          />
        );
      } else {
        return null;
      }
    });
  };
  return (
    <div>

      <Switch>
        {getRoutes(routes)}
        <Redirect from="*" to="/auth/login" />
      </Switch>
    </div>
  );
};

export default DummyCom;
{
  /* <div>
            <img src={require("../../assets/img/brand/argon-react.png")} alt="" style={
            {"float":"left","maxWidth":"100px","margin":"10px","position":"absolute"}
            } />
        </div>
        <div>
            <h3 className='' >About</h3>
        </div> */
}
